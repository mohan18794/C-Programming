#include <lpc21xx.h>
void ext_interrupt(void)__irq{
	EXTINT=0x02;
	IOCLR0=0x0f;
	VICVectAddr=0;
}
void ext_init(void){
	PINSEL0=0x20000000;
	VICIntEnable=0x8000;
	VICVectCntl0=0x20|15;
	VICVectAddr0=(unsigned long)ext_interrupt;
	EXTMODE=0x02;
	EXTPOLAR=0x02;	
}



	
 	
	



	
	
	
