#include <lpc21xx.h>

extern void ext_init(void);
int main(){
	ext_init();
	IODIR0=0x0f;
	IOSET0=0x0f;
	while(1){
	}
}