/*********************************************************************
**	Project Name : Keypad																						**
**  Pin Numbers  : 																									**
*********************************************************************/
#include <LPC214X.H>
#include "prototype.h"

/* Macro Definitions*/ 
#define ROW_ALL ((1<<17)|(1<<18)|(1<<19)|(1<<20))	  
#define COL_ALL ((1<<21)|(1<<22)|(1<<23)|(1<<24))

/* Function Prototype declaration*/
long int y;
void  row_a(void);
void  row_b(void);
void  row_c(void);
void  row_d(void);




int main()
{
	

  lcd_init();
  lcd_print("KeyPad Test");
  
		delay(1000);
		lcd_clear();
//	IOCLR0 |= (ROW_ALL | COL_ALL);
	while(1)
	{
		delay(100);
	//	lcd_clear();
	lcd_print("Key Pressed");
	lcdcmd(0xc0);
		IODIR1=ROW_ALL;
		IOCLR1=ROW_ALL;
		y=IOPIN1 & (COL_ALL);
		if(!(y == COL_ALL))							  
		{
			if(y == 0x01c00000)
				row_a(); 
			delay(100);
			if(y == 0x01a00000)
				row_b();
			delay(100);
			
			if(y == 0x01600000)
				row_c(); 
		delay(100);

			if(y == 0x00e00000)
				row_d(); 
		delay(100);

		}
							// clear display
  	}
}

void  row_a(void)
{
	long int x;
	IODIR1=COL_ALL;
	IOCLR1=COL_ALL;
	x=IOPIN1 & (ROW_ALL);
	if(!(x == (ROW_ALL)))							  
	{
	//	lcd_clear();
		if(x == 0x001c0000)
		lcd_print("0");
		
		if(x == 0x001a0000)
		lcd_print("1");
		
		if(x == 0x00160000)
		lcd_print("2");
		
		if(x == 0x000e0000)
		lcd_print("3");
		
	}
}
void  row_b(void)
{
	long int x;
	IODIR1=COL_ALL;
	IOCLR1=COL_ALL;
	x=IOPIN1 & (ROW_ALL);
	if(!(x == (ROW_ALL)))							  
	{
	//	lcd_clear();
		if(x == 0x001c0000)
		lcd_print("4");
		
		if(x == 0x001a0000)
		lcd_print("5");
		
		if(x == 0x00160000)
		lcd_print("6");
		
		if(x == 0x000e0000)
		lcd_print("7");
	}
}

void  row_c(void)
{
	long int x;
	IODIR1=COL_ALL;
	IOCLR1=COL_ALL;
	x=IOPIN1 & (ROW_ALL);
	if(!(x == (ROW_ALL)))							  
	{
	//	lcd_clear();
		if(x == 0x001c0000)
		lcd_print("8");

		if(x == 0x001a0000)
		lcd_print("9");
		
		if(x == 0x00160000)
		lcd_print("A");
		
		if(x == 0x000e0000)
		lcd_print("B");
		
	}
}
void  row_d(void)
{
	long int x;
	IODIR1=COL_ALL;
	IOCLR1=COL_ALL;
	x=IOPIN1 & (ROW_ALL);
	if(!(x == (ROW_ALL)))							  
	{
	//	lcd_clear();
		if(x == 0x001c0000)
		lcd_print("C");
		
		if(x == 0x001a0000)
		lcd_print("D");
		
		if(x == 0x00160000)
		lcd_print("E");
		
		if(x == 0x000e0000)
		lcd_print("F");
	}
}

/********************************************************************
**                         End of File  						   **
********************************************************************/


