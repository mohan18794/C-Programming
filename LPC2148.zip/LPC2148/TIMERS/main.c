#include<lpc21xx.h>
extern void timer_init(void);
void main()
{
	timer_init();
	IODIR0=0xff;
	while(1)
	{
		IOSET0=0xff;
	}
}