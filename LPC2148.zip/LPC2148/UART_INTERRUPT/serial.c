#include<lpc21xx.h>
void ram(void){
	int x=U0RBR;
	U0THR=x;
	while(!(U0LSR&0x20));
	VICVectAddr0=0x00;
}
void uart(void){
	PINSEL0=0x05;
	U0LCR=0x83;
	U0DLL=97;
	U0LCR=0x03;
	VICVectAddr0=(unsigned long)ram;
	VICVectCntl0=0x26;
	VICIntEnable=0x40;
	U0IER=0x01;
}