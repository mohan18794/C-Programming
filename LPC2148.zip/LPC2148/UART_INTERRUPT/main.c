#include<lpc21xx.h>
extern void uart(void);
void main(){
	uart();
	while(1){
	}
}