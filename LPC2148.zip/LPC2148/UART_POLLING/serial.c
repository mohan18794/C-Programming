#include<lpc21xx.h>
void uart()
{
	PINSEL0=0x05;
	U0LCR=0x83;
	U0DLL=97;
	U0LCR=0x03;
}