#include<lpc21xx.h>
extern void uart(void);
void main(){
	int x;
	uart();
	while(1){
		while(!(U0LSR &0x01));
		x=U0RBR;
		U0THR=x;
		while(! (U0LSR &0x20));
	}
}